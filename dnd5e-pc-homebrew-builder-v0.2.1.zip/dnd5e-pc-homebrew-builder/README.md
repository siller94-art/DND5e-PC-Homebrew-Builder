# D&D 5e PC Homebrew Builder v0.2.0

Foundry VTT V14 add-on for the official D&D 5e system. Scope: player-character custom content only.

## Included
- Native D&D5e Class creation
- Native D&D5e Subclass creation
- Feat/Feature creation
- Spell creation
- Background creation
- Equipment creation
- PDF upload/review panel
- Opens created content in the normal D&D5e Item sheet for full native editing

The PDF importer attempts text extraction when the Foundry client exposes PDF.js. If the client does not expose a parser, the PDF is still accepted and the review area remains available for pasted text.
